import torch
from transformers import StoppingCriteria

class StoppingCriteriaSub(StoppingCriteria):

    def __init__(self, stops = [], encounters=1):
      super().__init__()
      self.stops = stops
      self.ENCOUNTERS = encounters
      self.stop_flag = False

    def __call__(self, input_ids: torch.LongTensor, scores: torch.FloatTensor):
      left_cnt = (self.stops[0] == input_ids[0]).sum().item()
      right_cnt_1 = (self.stops[1] == input_ids[0]).sum().item()
      right_cnt_2 = (self.stops[2] == input_ids[0]).sum().item()
      right_cnt_3 = (self.stops[3] == input_ids[0]).sum().item()
      right_cnt_4 = (self.stops[4] == input_ids[0]).sum().item()
      right_cnt_5 = (self.stops[5] == input_ids[0]).sum().item() * 2
      right_cnt = right_cnt_1 + right_cnt_2 + right_cnt_3 + right_cnt_4 + right_cnt_5
      if left_cnt == right_cnt:
        return True
      
      return False


class StoppingCriteriaCloseJson(StoppingCriteria):

    def __init__(self, tokenizer):
      super().__init__()
      self.tokenizer = tokenizer

    def __call__(self, input_ids: torch.LongTensor, scores: torch.FloatTensor):
      left_cnt, right_cnt = 0, 0
      for idx in input_ids[0]:
        token = self.tokenizer.convert_ids_to_tokens(idx.item())
        left_cnt += token.count('{')
        right_cnt += token.count('}')

      if left_cnt == right_cnt:
        return True
      return False